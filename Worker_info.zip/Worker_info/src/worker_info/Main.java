/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package worker_info;

import java.util.ArrayList;
import java.util.List;
import worker_info.Validate;

/**
 *
 * @author Admin
 */
public class Main {

    public static void main(String[] args) {
        List<Worker> wk = new ArrayList<>();
        ManageWorker m = new ManageWorker();
        List<History> history = new ArrayList<>();
        Worker w1 = new Worker("quang", "W1", 12, 1234, "weqe");
        Worker w2 = new Worker("hanh", "W2", 12, 1234, "weqe");
        Worker w3 = new Worker("hong", "W3", 12, 1234, "weqe");
        
        wk.add(w1);
        wk.add(w2);
        wk.add(w3);
        
        do {
            m.menu();
            int choice = Validate.inputInt("Input yout choice", 1, 5);
            
            switch (choice) {
                case 1:
                    m.addWorker(wk);
                    break;
                case 2:
                    m.upSalary(wk, history);
                    break;
                case 3:
                    m.downSalary(wk, history);
                    break;
                case 4:
                    m.getInformationSalary(wk, history);
                    break;
                case 5:
                    return;
            }
        } while (true);

    }
}
