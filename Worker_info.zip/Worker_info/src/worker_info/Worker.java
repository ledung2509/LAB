/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package worker_info;

/**
 *
 * @author Admin
 */
public class Worker{

    private String name;
    private String id;
    private int age;
    private double salary;
    private String workLocation;
    
    //Constructor:

    public Worker() {
    }

    public Worker(String name, String id, int age, double salary, String workLocation) {
        this.name = name;
        this.id = id;
        this.age = age;
        this.salary = salary;
        this.workLocation = workLocation;
    }
    
    //Getter and Setter:

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getWorkLocation() {
        return workLocation;
    }

    public void setWorkLocation(String workLocation) {
        this.workLocation = workLocation;
    }

    @Override
    public String toString() {
        return String.format("%-7s %-10s %-10s %-15s", id, name, age, salary, workLocation);
    }


    
    
    
    
    
    
}
