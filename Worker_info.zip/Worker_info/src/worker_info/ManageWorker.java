/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package worker_info;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import worker_info.Validate;

/**
 *
 * @author Admin
 */
public class ManageWorker {

    void menu() {
        System.out.println("======== Worker Management =========\n"
                + "1.	Add Worker\n"
                + "2.	Up salary\n"
                + "3.	Down salary\n"
                + "4.	Display Information salary\n"
                + "5.	Exit");
    }

    void addWorker(List<Worker> wk) {
        System.out.println("--------- Add Worker ----------");
        String code;
        
        while (true) {            
            try {
                code = Validate.inputString("Enter ID: ");
                if(checkID(code, wk) == true){
                    System.out.println("Existed");
                } else
                    break;
            } catch (Exception e) {
                System.out.println("Again");
            }
            
        }
        
        String name = Validate.inputString("Enter name: ");
        int age = Validate.inputInt("Enter age: ", 0, Integer.MAX_VALUE);
        double salary = Validate.inputDouble("Enter salary: ", 0, Integer.MAX_VALUE);
        String workLocation = Validate.inputString("Enter work location: ");
        Worker e = new Worker(name, code, age, salary, workLocation);
        wk.add(e);
    }

    void upSalary(List<Worker> wk, List<History> history) {

        System.out.println("------- Up Salary --------");
        String code = Validate.inputString("Enter code to up salary: ");
        double salary = 0;
        if (checkID(code, wk)) {
            salary = Validate.inputDouble("Enter salary to increase: ", 0, Integer.MAX_VALUE);
        } else {
            System.out.println("Not found ID");
            return;
        }
        int pos = searchCode1(code, wk);
        wk.get(pos).setSalary(salary + wk.get(pos).getSalary());
        Worker w = wk.get(pos);

        LocalDateTime obj = LocalDateTime.now();
        DateTimeFormatter formater = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
        String date = obj.format(formater);

        History h = new History("UP", date, w.getName(), w.getId(), w.getAge(), w.getSalary(), w.getWorkLocation());
        history.add(h);
    }

    public void downSalary(List<Worker> wk, List<History> history) {
        System.out.println("------- Down Salary --------");
        String code = Validate.inputString("Enter code to down salary: ");
        double salary = 0;
        if (checkID(code, wk)) {
            salary = Validate.inputDouble("Enter salary to decrease: ", 0, Integer.MAX_VALUE);
        } else {
            System.out.println("Not found ID");
            return;
        }
        
        int pos = searchCode1(code, wk);
        if (salary > wk.get(pos).getSalary()) {
            salary = Validate.inputDouble("Input again: ", 0, Integer.MAX_VALUE);
        }
        
        Worker w = wk.get(pos);
        LocalDateTime obj = LocalDateTime.now();
        DateTimeFormatter formater = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
        String date = obj.format(formater);

        History h = new History("DOWN", date, w.getName(), w.getId(), w.getAge(), w.getSalary(), w.getWorkLocation());
        history.add(h);

        wk.get(pos).setSalary(wk.get(pos).getSalary() - salary);
        display(wk);
    }

    void display(List<Worker> wk) {
        System.out.println("--------------------Display Information Salary-----------------------\n");
        System.out.printf("%-7s %-10s %-10s %-15s\n", "ID", "Name", "Age", "Salary", "WorkLocation");
        for (Worker worker : wk) {
            System.out.println(worker);
        }
        
        
    }

    boolean checkID(String code, List<Worker> wk) {
        // check id co ton tai hay k
        for (int i = 0; i < wk.size(); i++) {
            if (code.equals(wk.get(i).getId())) {
                return true;
            }
        }
        return false;
    }
     
    int searchCode1(String code, List<Worker> wk) {
        // Tra ve vi tri index cua worker trong list worker
        for (int i = 0; i < wk.size(); i++) {
            if (code.equals(wk.get(i).getId())) {
                return i;
            }
        }
        return -1;
    }

    void getInformationSalary(List<Worker> wk, List<History> history) {
//        Collections.sort(wk, new Comparator<Worker>() {
//            @Override
//            public int compare(Worker t, Worker t1) {
//                return t.getName().compareTo(t1.getName());
//            }
//        });
        
         System.out.println("--------------------Display Information Salary-----------------------\n");
        System.out.printf("%-7s %-10s %-10s %-10s %-10s %-10s\n", "ID", "Name", "Age", "Salary", "Status","Date");
        for (History history1 : history) {
            System.out.println(history1);
        }
    }
    
    

}
